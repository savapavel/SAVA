import { useEffect } from 'react';
import MainButton from './components/MainButton';

function App() {
  useEffect(() => {
    window.Telegram.WebApp.ready();
    window.Telegram.WebApp.expand();
  }, []);

  return (
    <div className="App">
      <MainButton />
    </div>
  );
}