export default function MainButton() {
  const sendData = () => {
    const data = {
      user: window.Telegram.WebApp.initDataUnsafe.user,
      action: "button_click"
    };
    window.Telegram.WebApp.sendData(JSON.stringify(data));
  };

  return (
    <button onClick={sendData}>
      Confirm Action
    </button>
  );
}