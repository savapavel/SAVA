from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor
import os

bot = Bot(token=os.getenv(""))
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    button = types.KeyboardButton(
        "Open WebApp", 
        web_app=types.WebAppInfo(url="https://ваш_домен")
    )
    keyboard = types.ReplyKeyboardMarkup().add(button)
    
    await message.answer(
        "Нажмите кнопку ниже!", 
        reply_markup=keyboard
    )

if __name__ == "__main__":
    executor.start_polling(dp)