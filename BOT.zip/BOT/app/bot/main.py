# main.py
import asyncio
from app.db.database import create_tables  # Импорт вашей функции

async def main():
    try:
        await create_tables()  # Ваша асинхронная функция
        print("Таблицы созданы успешно!")
    except Exception as e:
        print(f"Ошибка: {e}")

if __name__ == "__main__":
    asyncio.run(main())  # Запуск асинхронного кода