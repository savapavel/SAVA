from aiogram import Router, F
from aiogram.types import Message

router = Router()

@router.message(F.text == "/my_stats")
async def show_stats(message: Message, db: Session):
    stats = db.query(UserActivity).filter_by(
        user_id=str(message.from_user.id),
        chat_id=str(message.chat.id)
    ).first()
    
    await message.answer(
        f"📊 Ваша активность:\n"
        f"Сообщений: {stats.messages}\n"
        f"Лайков: {stats.likes}\n"
        f"Рейтинг: #{stats.score}"
    )