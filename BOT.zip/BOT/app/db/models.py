from sqlalchemy import Column, Integer, String, BigInteger
from database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    telegram_id = Column(BigInteger, unique=True)
    username = Column(String(50))
    full_name = Column(String(100))


