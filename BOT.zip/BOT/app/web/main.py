import asyncio
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from app.db.database import create_tables
from .routers import webapp
from fastapi import WebSocket

# Инициализация FastAPI должна быть ПЕРВОЙ
app = FastAPI()

# Затем подключаем роутеры
app.include_router(webapp.router)

# Подключение статических файлов (CSS/JS)
app.mount("/static", StaticFiles(directory="static"), name="static")

# Создание таблиц при старте (асинхронно)
@app.on_event("startup")
async def on_startup():
    try:
        await create_tables()
        print("✅ Таблицы в БД созданы успешно!")
    except Exception as e:
        print(f"❌ Ошибка при создании таблиц: {e}")

# WebApp интерфейс
@app.get("/", response_class=HTMLResponse)
async def web_app(request: Request):
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Telegram Mini App</title>
        <script src="https://telegram.org/js/telegram-web-app.js"></script>
        <link href="/static/style.css" rel="stylesheet">
    </head>
    <body>
        <div class="container">
            <h1 id="header">Добро пожаловать!</h1>
            <button onclick="Telegram.WebApp.sendData('Hello')">Отправить данные</button>
        </div>
    </body>
    </html>
    """

# Тестовый JSON-эндпоинт
@app.get("/api/hello")
async def hello():
    return {"message": "Hello from FastAPI!"}
    
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            await manager.broadcast(f"Получены данные: {data}")
    except WebSocketDisconnect:
        manager.disconnect(websocket)
        await manager.broadcast("Клиент отключился")

# Запуск только для dev-режима
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)  # Исправлены хост и порт