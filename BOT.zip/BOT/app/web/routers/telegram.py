from fastapi import APIRouter, Request
import logging

router = APIRouter()

@router.post("/api/data")
async def handle_telegram_data(request: Request):
    data = await request.json()
    logging.info(f"Received Telegram data: {data}")
    return {"status": "success"}