from fastapi import APIRouter, Request
import logging

router = APIRouter()

@router.post("/web-data")
async def handle_web_data(request: Request):
    data = await request.json()
    logging.info(f"Received data: {data}")
    
    # Здесь можно добавить логику обработки
    return {
        "status": "success",
        "data": data
    }