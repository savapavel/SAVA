from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

router = APIRouter()

@router.get("/stats/{chat_id}")
async def get_chat_stats(chat_id: str, db: Session = Depends(get_db)):
    stats = db.query(UserActivity).filter_by(chat_id=chat_id).order_by(
        UserActivity.score.desc()
    ).limit(10).all()
    
    return {
        "top_users": [
            {"user_id": s.user_id, "score": s.score} 
            for s in stats
        ]
    }