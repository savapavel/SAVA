from sqlalchemy.orm import Session

def calculate_score(db: Session, chat_id: str):
    """Обновляет рейтинг для всех пользователей чата"""
    activities = db.query(UserActivity).filter_by(chat_id=chat_id).all()
    for activity in activities:
        activity.score = activity.messages * 1 + activity.likes * 2
    db.commit()