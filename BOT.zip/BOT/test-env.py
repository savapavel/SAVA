import os
from dotenv import load_dotenv

load_dotenv()  # Загружает переменные из .env

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
print("Токен бота:", TOKEN if TOKEN else "Не найден!")